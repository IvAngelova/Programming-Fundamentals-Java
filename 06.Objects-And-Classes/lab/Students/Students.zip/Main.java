package T6ObjectsAndClasses.lab.Students;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
         Scanner scan = new Scanner(System.in);
         String input = scan.nextLine();
        List <Student> students = new ArrayList<>();
         while (!input.equals("end")){
             String [] studentInfo = input.split(" ");
             String firstName = studentInfo[0];
             String lastName = studentInfo[1];
             int age = Integer.parseInt(studentInfo[2]);
             String hometown = studentInfo[3];

             Student currentStudent = new Student(firstName, lastName, age, hometown);
             students.add(currentStudent);
             input = scan.nextLine();
         }
         String city = scan.nextLine();
        for (Student student : students) {
            if(city.equals(student.getHometown())){
                System.out.printf("%s %s is %d years old%n",
                        student.getFirstName(), student.getLastName(), student.getAge());
            }
        }
    }
}
